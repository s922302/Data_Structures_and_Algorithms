iVal=input('請輸入8進制數值:')
print('您所輸入8進制數值，代表10進制:%d' %int(iVal,8))
print('')

iVal=input('請輸入10進制數值:')
print('您所輸入10進制數值，代表8進制:%o' %int(iVal,10))
print('')

iVal=input('請輸入16進制數值:')
print('您所輸入16進制數值，代表10進制:%d' %int(iVal,16))
print('')

iVal=input('請輸入10進制數值:')
print('您所輸入10進制數值，代表16進制:%x' %int(iVal,10))
print('')
