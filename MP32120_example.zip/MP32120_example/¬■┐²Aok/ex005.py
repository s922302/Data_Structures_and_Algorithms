print('1.80以上,2.60~79,3.59以下')
ch=input('請輸入分數群組: ')
#條件敘述開始
if ch=='1':
    print('繼續保持!')
elif ch=='2':
    print('還有進步空間!!')
elif ch=='3':
    print('請多多努力!!!')
else:
    print('error')
